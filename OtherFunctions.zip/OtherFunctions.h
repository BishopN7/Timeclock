// Developer Name: Lyric Hart
// Date: March 24, 2024
#ifndef OTHERFUNCTIONS_H
#define OTHERFUNCTIONS_H

void displayMenu();

#endif 