#include <iostream>

using namespace std;

// The display menu options function
/* Void declares the display menu as
   a function, but won't return any
   data, when outside the main function.*/
void displayMenu() {
    cout << "*************************" << endl;
    cout << "* 1 - Add One Hour      *" << endl;
    cout << "                         " << endl;
    cout << "* 2 - Add One Minute    *" << endl;
    cout << "                         " << endl;
    cout << "* 3 - Add One Second    *" << endl;
    cout << "                         " << endl;
    cout << "* 4 - Exit Program      *" << endl;
    cout << "*************************" << endl;

}