#include <iostream> // This is for input/ouptput operations 
#include <iomanip> // This is for input/output manipulation
#include <string> // This is for string input
#include "OtherFunctions.h" // This is for the header file

// Contains the standard C++ objects within its library
using namespace std;



int main() {

    // Defined variables for the clock
    int hour, minute, second, h12;
    char choice, colon;
    string AmPm;

    // Obtain user input for 12-hour-clock format
    cout << "Please enter initial time (HH:MM:SS) 24-clock format: ";
    cin >> hour >> colon >> minute >> colon >> second;

    if (hour < 1 || hour > 23 || minute < 0 || minute > 59 || second < 0 || second > 59) {
        cout << "Error: Invalid Time Input! Please enter the correct values." << endl;
        return 1;
    }

    do {
        // Display the time in both formats
        cout << setw(2) << setfill('0') << hour << ":"
            << setw(2) << setfill('0') << minute << ":"
            << setw(2) << setfill('0') << second << "    " << "24-Hour" << endl;

        // A simple version 12-hour conversion and AM/PM setting
        AmPm = "AM";
        if (hour == 0) {
            h12 = 12;
        }
        else if (hour < 12) {
            h12 = hour;
        }
        else if (hour == 12) {
            AmPm = "PM";
            h12 = hour;
        }
        else {
            AmPm = "PM";
            h12 = hour - 12;
        }

        cout << // Set minimum field width for hour to 2 characters (pad with leading zeros if needed) 
            setw(2) << setfill('0') << h12 << ":"
            // Set minimum field width for minute to 2 characters (pad with leading zeros if needed)
            << setw(2) << setfill('0') << minute << ":"
            // Set minimum field width for second to 2 characters (pad with leading zeros if needed)
            << setw(2) << setfill('0') << second << " " << AmPm << "  12-Hour" << endl;

        // This calls the display menu inside the main function
        displayMenu();

        // Ask for the user's input when it comes to the display selection
        cin.clear();
        cin.ignore(10000, '\n');

        // Ask for the user's input when it comes to the display selection
        cout << "Please select your choice (1-4)" << endl;
        cin >> choice;

        // Switch statement for each choice entered by the user
        switch (choice) {
        case '1':
            hour++;            // Increment each hour by one; handle carry-over
            break;
        case '2':
            minute++;          // Increment each minute by one; handle carry-over
            break;
        case '3':
            second++;          // Increment each second by one; handle carry-over
            break;              // Handle minute rollover        
        case '4':
            cout << "Exiting Program..." << endl; // The user decides to exit the program
            break;
        default: // In case the user does not enter one of the options (1-4)

            cout << "Invalid Entry! Please try again from the selection menu." << endl;
        }
        if (second == 60) {
            second = 0;
            minute++;
        }
        if (minute == 60) {
            minute = 0;
            hour++;
        }
        hour = hour % 24;

    } while (choice != '4');

    return 0;
}